<?php


require "./include/ConsultarSucursalesConfig.php";
require "./include/ConsultarSucursales.php";

$codigoPostal = NULL;
$localidad = NULL;
$provincia = NULL;

ConsultarSucursales($username, $password, $urlTest, $codigoPostal, $localidad, $provincia);

?>	