<?php


require "./include/TrazabilidadConfig.php";
require "./include/ObtenerTrazabilidad.php";

$codigoCliente = 'CL0009069';
$nroPieza = '';
$nroAndreani = '*00004990';

ObtenerTrazabilidad($urlTest, $codigoCliente, $nroPieza, $nroAndreani);

?>	