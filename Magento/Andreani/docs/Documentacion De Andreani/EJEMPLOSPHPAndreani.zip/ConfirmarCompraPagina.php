<?php

require "./include/ImposicionRemotaConfig.php";
require "./include/ConfirmarCompra.php";

$calle = 'calle 1';
$categoriaDistancia = NULL;
$categoriaFacturacion = NULL;
$categoriaPeso = NULL;
$codigoPostalDestino = '5000';
$contrato = '300005270';
$departamento = '3';
$detalleProductosEntrega = 'zapatos magicos';
$detalleProductosRetiro = NULL;
$email = 'mail@dominio.com.ar';
$localidad = 'C.A.B.A';
$nombreApellido = 'Juan Perez';
$nombreApellidoAlternativo = 'Jorge Lopez';
$numero = '1332';
$numeroCelular = '1512345678';
$numeroDocumento = '32123456';
$numeroTelefono = '41234567';
$numeroTransaccion = 'Transaccion 115';
$peso = 1000;
$piso = '1';
$provincia = 'C.A.B.A';
$sucursalCliente = NULL;
$sucursalRetiro = NULL;
$tarifa = 0;
$tipoDocumento = 'DNI';
$valorACobrar = NULL;
$valorDeclarado = 650;
$volumen = 1000;

ConfirmarCompra($username, $password, $urlTest, $calle, $categoriaDistancia, $categoriaFacturacion, $categoriaPeso, $codigoPostalDestino, $contrato,
                $departamento, $detalleProductosEntrega, $detalleProductosRetiro, $email, $localidad, $nombreApellido, $nombreApellidoAlternativo,
				$numero, $numeroCelular, $numeroDocumento, $numeroTelefono, $numeroTransaccion, $peso, $piso, $provincia, $sucursalCliente,
				$sucursalRetiro, $tarifa, $tipoDocumento, $valorACobrar, $valorDeclarado, $volumen);

?>	