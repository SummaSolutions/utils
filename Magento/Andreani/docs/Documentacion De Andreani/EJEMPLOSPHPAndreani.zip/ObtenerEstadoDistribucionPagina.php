<?php


require "./include/TrazabilidadConfig.php";
require "./include/ObtenerEstadoDistribucion.php";

$codigoCliente = '';
$nroPieza = '';
$nroAndreani = '';

ObtenerEstadoDistribucion($urlTest, $codigoCliente, $nroPieza, $nroAndreani);

?>	