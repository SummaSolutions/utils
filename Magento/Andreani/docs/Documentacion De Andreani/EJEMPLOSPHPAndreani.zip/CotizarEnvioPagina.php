<?php


require "./include/CotizarEnvioConfig.php";
require "./include/CotizarEnvio.php";

$cpDestino = '1828';
$cliente = 'CL0003750';
$contrato = '300005270';
$peso = 500;
$sucursalRetiro = 56;
$valorDeclarado = 150;
$volumen = 1000;

CotizarEnvio($username, $password, $urlTest, $cpDestino, $cliente, $contrato, $peso, $sucursalRetiro, $valorDeclarado, $volumen);

?>	