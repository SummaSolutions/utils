<?php


require "./include/ImposicionRemotaConfig.php";
require "./include/ImprimirConstancia.php";

$nroAndreani = '';

ImprimirConstancia($username, $password, $urlTest, $nroAndreani);

?>	