<?php

$username = 'eCommerce_Integra'; //Usuario de eAndreani
$password = 'passw0rd'; //password de eAndreani
$urlTest = 'https://www.e-andreani.com/CasaStaging/ecommerce/ImposicionRemota.svc?wsdl';
//$urlProd = "https://www.e-andreani.com/CasaWS/eCommerce/ImposicionRemota.svc?wsdl";

?>