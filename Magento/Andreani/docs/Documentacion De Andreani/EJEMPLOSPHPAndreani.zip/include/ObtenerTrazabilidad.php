<?php

function ObtenerTrazabilidad($url, $codigoCliente, $nroPieza, $nroAndreani){
	
	try
	{
		$optionsSoap = array(
			'soap_version' => SOAP_1_2,
			'exceptions' => 1,
			'trace' => 1,
			'style' => SOAP_DOCUMENT,
			'encoding'=> SOAP_LITERAL,
		);

		$optRequest = array();
		$optRequest["ObtenerTrazabilidad"] = array(
			'Pieza' =>array(
				  'NroPieza'=>$nroPieza
				 ,'NroAndreani'=>$nroAndreani
				 ,'CodigoCliente'=>$codigoCliente
							));	  
		$client = new SoapClient($url, $optionsSoap);
		$request = $client->__soapCall("ObtenerTrazabilidad", $optRequest);
		var_dump($request);
	} catch (SoapFault $e) {
		var_dump(libxml_get_last_error());
		echo "<BR><BR>";
		var_dump($e);
	}
}
?>