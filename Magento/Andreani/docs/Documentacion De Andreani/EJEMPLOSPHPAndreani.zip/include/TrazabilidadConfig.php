<?php

$urlTest = 'https://www.e-andreani.com/eAndreaniWSStaging/Service.svc?wsdl';
//$urlProd = "https://www.e-andreani.com/eAndreaniWS/Service.svc?wsdl";

?>