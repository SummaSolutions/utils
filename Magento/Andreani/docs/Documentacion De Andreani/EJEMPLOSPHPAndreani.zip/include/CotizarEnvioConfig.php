<?php

$username = 'eCommerce_Integra';
$password = 'passw0rd';
$urlTest = 'https://www.e-andreani.com/CasaStaging/eCommerce/CotizacionEnvio.svc?wsdl';
//$urlProd = "https://www.e-andreani.com/CasaWS/eCommerce/CotizacionEnvio.svc?wsdl";

?>