<?php

function ObtenerEstadoDistribucion($url, $codigoCliente, $nroPieza, $nroAndreani){
	
	try
	{
		$optionsSoap = array(
			'soap_version' => SOAP_1_2,
			'exceptions' => 1,
			'trace' => 1,
			'style' => SOAP_DOCUMENT,
			'encoding'=> SOAP_LITERAL,
		);
		
		$optRequest = array();
		$optRequest["ObtenerEstadoDistribucion"] = array(
			'Consulta' =>array(
						 'CodigoCliente'=>$codigoCliente
						,'Piezas' =>array(
								'Pieza' =>array(
										 'NroPieza'=>$nroPieza
										,'NroAndreani'=>$nroAndreani
								))));
			
	$client = new SoapClient($url, $optionsSoap);
	$result = $client->__soapCall("ObtenerEstadoDistribucion", $optRequest);
	var_dump($result);
	} catch (SoapFault $e) {
		var_dump(libxml_get_last_error());
		echo "<BR><BR>";
		var_dump($e);
	}
}

?>